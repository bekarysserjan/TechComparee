package com.techcompare.smartphone;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Maps the existing Supabase smartphones table.
 * This class describes stored data; it does not calculate scores.
 */
@Entity
@Table(name = "smartphones")
public class Smartphone {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String brand;

    private Integer geekbenchMulti;
    private Integer geekbenchSingle;
    private Integer antutuGpuScore;
    private Integer ramGb;
    private Integer storageGb;
    private Integer batteryMah;
    private Integer mainCameraMp;
    private Integer hasTelephotoLens;
    private Integer videoMaxFps;
    private Integer frontCameraMp;
    private Integer screenRefreshHz;
    private Integer screenBrightnessNits;
    private Integer weightG;
    @jakarta.persistence.Column(name = "has_5g")
    private Boolean has5g;

    protected Smartphone() {
        // Required by JPA.
    }

    public Integer getId() { return id; }
    public String getName() { return name; }
    public String getBrand() { return brand; }
    public Integer getGeekbenchMulti() { return geekbenchMulti; }
    public Integer getGeekbenchSingle() { return geekbenchSingle; }
    public Integer getAntutuGpuScore() { return antutuGpuScore; }
    public Integer getRamGb() { return ramGb; }
    public Integer getStorageGb() { return storageGb; }
    public Integer getBatteryMah() { return batteryMah; }
    public Integer getMainCameraMp() { return mainCameraMp; }
    public Integer getHasTelephotoLens() { return hasTelephotoLens; }
    public Integer getVideoMaxFps() { return videoMaxFps; }
    public Integer getFrontCameraMp() { return frontCameraMp; }
    public Integer getScreenRefreshHz() { return screenRefreshHz; }
    public Integer getScreenBrightnessNits() { return screenBrightnessNits; }
    public Integer getWeightG() { return weightG; }
    public Boolean getHas5g() { return has5g; }
}
