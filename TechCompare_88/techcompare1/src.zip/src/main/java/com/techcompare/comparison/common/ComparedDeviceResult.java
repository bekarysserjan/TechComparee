package com.techcompare.comparison.common;

import java.util.Map;

/** Scores and ranking for one device in a multi-device comparison. */
public record ComparedDeviceResult(
        Integer deviceId,
        String deviceName,
        String brand,
        Integer overallScore,
        Integer availableCategoryWeight,
        Integer rank,
        Map<String, Integer> categoryScores
) {
}
