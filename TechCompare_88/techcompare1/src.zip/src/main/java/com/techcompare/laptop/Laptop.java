package com.techcompare.laptop;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.math.BigDecimal;

/**
 * Maps the existing Supabase laptops table.
 * This class describes stored data; it does not calculate scores.
 */
@Entity
@Table(name = "laptops")
public class Laptop {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String brand;

    private Integer geekbenchMulti;
    private Integer geekbenchSingle;
    private Integer gpuBenchmarkScore;
    private Integer ramGb;
    private Integer storageGb;
    private Integer screenResolutionPixels;
    private BigDecimal screenSizeInch;
    private String panelType;
    private Boolean hasTouchscreen;
    private BigDecimal weightKg;
    private Integer batteryLifeHours;

    protected Laptop() {
        // Required by JPA.
    }

    public Integer getId() { return id; }
    public String getName() { return name; }
    public String getBrand() { return brand; }
    public Integer getGeekbenchMulti() { return geekbenchMulti; }
    public Integer getGeekbenchSingle() { return geekbenchSingle; }
    public Integer getGpuBenchmarkScore() { return gpuBenchmarkScore; }
    public Integer getRamGb() { return ramGb; }
    public Integer getStorageGb() { return storageGb; }
    public Integer getScreenResolutionPixels() { return screenResolutionPixels; }
    public BigDecimal getScreenSizeInch() { return screenSizeInch; }
    public String getPanelType() { return panelType; }
    public Boolean getHasTouchscreen() { return hasTouchscreen; }
    public BigDecimal getWeightKg() { return weightKg; }
    public Integer getBatteryLifeHours() { return batteryLifeHours; }
}
